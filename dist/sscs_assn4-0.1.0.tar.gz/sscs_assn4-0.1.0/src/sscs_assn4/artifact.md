je2230

New test artifact for assn 2!